#!/bin/sh

echo $HOST
echo $PORT
echo $CUSTOM_ARGS
