<!--
👋 Hello! As Nova users browse the extensions library, a good README can help them understand what your extension does, how it works, and what setup or configuration it may require.

Not every extension will need every item described below. Use your best judgement when deciding which parts to keep to provide the best experience for your new users.

💡 Quick Tip! As you edit this README template, you can preview your changes by selecting **Extensions → Activate Project as Extension**, opening the Extension Library, and selecting "{{ name }}" in the sidebar.

Let's get started!
-->

<!--
🎈 Include a brief description of the clips your extension provides. For example:
-->
**{{ name }}** provides clips for **A Popular Framework**, including the most important feature, something that's really helpful, and _a little-known secret!_

## Details

<!--
🎈 To help users get a feel for how clips provided by your extension will work in practice, consider listing them along with any keyboard shortcuts or triggers they use:
-->

| Title         | Description                           | Trigger    |
| ---           | ---                                   | :-:        |
| **lipsum-5w** | Inserts 5 words of _Lorem ipsum_      | `lipsum5w` |
| **lipsum-1p** | Inserts 1 paragraph of _Lorem ipsum_  | `lipsum1p` |
| **lipsum-5p** | Inserts 5 paragraphs of _Lorem ipsum_ | `lipsum5p` |

<!--
🎈 If your extension provides too many clips to list, that's okay! Instead, consider providing an overview of what users might expect to find:
-->

{{ name }} offers clips in the following categories:

- Lorem
- Ipsum
- Dolor
- Sit
- Amet

<!--
👋 That's it! Happy developing!

P.S. If you'd like, you can remove these comments before submitting your extension 😉
-->
