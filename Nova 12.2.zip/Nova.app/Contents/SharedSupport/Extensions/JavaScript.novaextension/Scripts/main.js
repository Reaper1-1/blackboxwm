// Tasks
const Tasks = require("Tasks.js");
nova.assistants.registerTaskAssistant(Tasks, {
    identifier: "javascript",
    name: "JavaScript"
});
