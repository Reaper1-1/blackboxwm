// Files
const Files = require("Files.js");
// Note: This API is private, and may disappear at any point. Do not attempt to use it.
nova.assistants.registerFileAssistant("markdown", Files);
